# Tabungan Digital – Aplikasi Android

Pengingat menabung otomatis (default: tiap hari Rabu jam 00.00, 12.00, 18.00).

## Cara mendapatkan APK (tanpa Android Studio)
1. Buat repository baru di GitHub, upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → **Build APK** → **Run workflow**.
3. Setelah selesai (±5 menit), unduh artifact **tabungan-digital-apk** → ekstrak → `app-debug.apk`.
4. Kirim APK ke HP, buka, izinkan "install dari sumber ini", lalu izinkan notifikasi saat diminta.

## Mengubah jadwal
Edit `www/app-notifications.js`: `REMINDER_WEEKDAYS` (hari) dan `REMINDER_TIMES` (jam).
Setelah itu build ulang APK dan pasang ulang.

## Catatan
- Folder `www` adalah salinan website (sudah termasuk pembatasan barcode hanya hari Rabu).
  Bila website berubah, salin file barunya ke `www`.
- Login passkey (WebAuthn) terikat ke domain website, jadi tidak berlaku di dalam aplikasi; login memakai username & password.
